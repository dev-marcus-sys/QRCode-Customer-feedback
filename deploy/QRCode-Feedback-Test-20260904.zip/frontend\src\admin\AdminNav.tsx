/**
 * F-010 管理後台共用導覽：個案 / QR / 問卷 / 儀表板 / 參數 / 用戶 / 角色 / 審計。
 * 置於各管理頁頂部，便於在 F-010 與其他模組間切換。
 */
import { ToggleButton, ToggleButtonGroup } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const SECTIONS = [
  { key: 'cases', label: '個案', path: '/admin/cases' },
  { key: 'qr', label: 'QR Code', path: '/admin/qr' },
  { key: 'surveys', label: '問卷', path: '/admin/surveys' },
  { key: 'dashboard', label: '儀表板', path: '/admin/dashboard' },
  { key: 'config', label: '參數', path: '/admin/config' },
  { key: 'users', label: '用戶', path: '/admin/users' },
  { key: 'roles', label: '角色', path: '/admin/roles' },
  { key: 'audit', label: '審計', path: '/admin/audit' },
];

export default function AdminNav({ current }: { current: string }) {
  const navigate = useNavigate();
  return (
    <ToggleButtonGroup
      size="small"
      exclusive
      value={current}
      onChange={(_, v: string | null) => {
        if (v) {
          const s = SECTIONS.find((x) => x.key === v);
          if (s) navigate(s.path);
        }
      }}
      sx={{ flexWrap: 'wrap' }}
    >
      {SECTIONS.map((s) => (
        <ToggleButton key={s.key} value={s.key}>
          {s.label}
        </ToggleButton>
      ))}
    </ToggleButtonGroup>
  );
}
